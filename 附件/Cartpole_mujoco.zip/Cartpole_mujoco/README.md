1. install glfw, Eigen3, CppAD, matplotlib-cpp, yaml-cpp
2. mkdir build && cd build
3. cmake ..
4. make -j
5. ./bin/main
